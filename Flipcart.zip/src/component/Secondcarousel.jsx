import React from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Typography } from '@mui/material';
import ArrowCircleLeftOutlinedIcon from '@mui/icons-material/ArrowCircleLeftOutlined';


function Secondcarousel() {
    const settings = {
        dots: false,
        infinite: true,
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: false,
        speed: 2000,
        autoplaySpeed: 2000,
        cssEase: "linear"
    };
    return (
        <Box sx={{height:'500px',}}>
            <Grid container spacing={2} >
                <Grid item xs={10}>
                    <Box sx={{ mt: 2, backgroundColor: ' #d0d3d4 ',mb:10,height:'450px'}}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Typography variant='h4' sx={{ m: 2,fontWeight:'normal' }}>Best Deals on Smartphones</Typography>
                            <ArrowCircleLeftOutlinedIcon sx={{ m: 2 }} />
                        </Box>
                        <div className="slider-container">
                
                            <Slider {...settings} sx={{gap:2}}>
                           
                                <Box sx={{width:'10%',height:'300px',border:'1px solid grey',display:'flex',alignItems:'center',}}>
                                   
                                   <img src='https://rukminim2.flixcart.com/image/210/210/xif0q/mobile/y/9/0/-original-imahyuhfg2z4fvyh.jpeg?q=80' style={{width:'230px',height:'200px',padding:'20px 15px 20px 15px'}} alt='...' />
                                   <Typography variant='h6' sx={{color:'grey',textAlign:'center'}}>Realme P1 5g</Typography>
                                   <Typography variant='h6' sx={{fontWeight:'bold',textAlign:'center'}}>From $14,999</Typography>
                          </Box>
                                         
                          <Box sx={{width:'10%',height:'300px',border:'1px solid grey',display:'flex',alignItems:'center',ml:4}}>
                                   
                                   <img src='https://rukminim2.flixcart.com/image/210/210/xif0q/mobile/g/b/x/-original-imagtt4h4ptmxgwn.jpeg?q=80' style={{width:'230px',height:'200px',padding:'10px 15px 10px 15px',}} alt='...' />
                                   <Typography variant='h6' sx={{color:'grey',textAlign:'center'}}>Realme P1 5g</Typography>
                                   <Typography variant='h6' sx={{fontWeight:'bold',textAlign:'center'}}>From $14,999</Typography>
                          </Box>
                          <Box sx={{width:'10%',height:'300px',border:'1px solid grey',display:'flex',alignItems:'center',ml:6}}>
                                   
                                   <img src='https://rukminim2.flixcart.com/image/210/210/xif0q/mobile/d/h/q/m6-pro-5g-mzb0eprin-poco-original-imags3e7vewsafst.jpeg?q=80' style={{width:'230px',height:'200px',padding:'10px 15px 10px 15px'}} alt='...' />
                                   <Typography variant='h6' sx={{color:'grey',textAlign:'center'}}>Realme P1 5g</Typography>
                                   <Typography variant='h6' sx={{fontWeight:'bold',textAlign:'center'}}>From $14,999</Typography>
                          </Box>
                          <Box sx={{width:'10%',height:'300px',border:'1px solid grey',display:'flex',alignItems:'center',ml:8}}>
                                   
                                   <img src='https://rukminim2.flixcart.com/image/210/210/xif0q/mobile/u/v/h/-original-imagxaqtzmqgtfen.jpeg?q=80' style={{width:'230',height:'200px',padding:'10px 15px 10px 15px'}} alt='...' />
                                   <Typography variant='h6' sx={{color:'grey',textAlign:'center'}}>Realme P1 5g</Typography>
                                   <Typography variant='h6' sx={{fontWeight:'bold',textAlign:'center'}}>From $14,999</Typography>
                          </Box>
                          <Box sx={{width:'10%',height:'300px',border:'1px solid grey',display:'flex',alignItems:'center',ml:10}}>
                                   
                                   <img src='https://rukminim2.flixcart.com/image/210/210/xif0q/mobile/i/k/l/edge-50-fusion-pb300001in-motorola-original-imahywzpfd2jh9ep.jpeg?q=80' style={{width:'230px',height:'200px',padding:'10px 15px 10px 15px'}} alt='...' />
                                   <Typography variant='h6' sx={{color:'grey',textAlign:'center'}}>Realme P1 5g</Typography>
                                   <Typography variant='h6' sx={{fontWeight:'bold',textAlign:'center'}}>From $14,999</Typography>
                          </Box>
                          <Box sx={{width:'10%',height:'300px',border:'1px solid grey',display:'flex',alignItems:'center',ml:12}}>
                                   
                                   <img src='https://rukminim2.flixcart.com/image/210/210/xif0q/mobile/m/r/p/-original-imahyzygqydqtyvj.jpeg?q=80' style={{width:'230px',height:'200px',padding:'10px 15px 10px 15px'}} alt='...' />
                                   <Typography variant='h6' sx={{color:'grey',textAlign:'center'}}>Realme P1 5g</Typography>
                                   <Typography variant='h6' sx={{fontWeight:'bold',textAlign:'center'}}>From $14,999</Typography>
                          </Box>
                          <Box sx={{width:'10%',height:'300px',border:'1px solid grey',display:'flex',alignItems:'center',ml:14}}>
                                   
                                   <img src='https://rukminim2.flixcart.com/image/210/210/xif0q/mobile/m/r/p/-original-imahyzygqydqtyvj.jpeg?q=80' style={{width:'230px',height:'200px',padding:'10px 15px 10px 15px'}} alt='...' />
                                   <Typography variant='h6' sx={{color:'grey',textAlign:'center'}}>Realme P1 5g</Typography>
                                   <Typography variant='h6' sx={{fontWeight:'bold',textAlign:'center'}}>From $14,999</Typography>
                          </Box>
                                
                              
                               
                               
                            </Slider>
                        </div>
                        </Box>
                </Grid>
                <Grid item xs={2}>
                    <Box sx={{mt:3}}>
                        <img  src='https://rukminim2.flixcart.com/fk-p-flap/530/810/image/6c0a8888ed7a580a.jpeg?q=20' style={{width:'300px',height:'450px'}} alt='...'/>
                    </Box>
                </Grid>

            </Grid>
        </Box>
    )
}

export default Secondcarousel
