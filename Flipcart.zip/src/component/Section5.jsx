import React from 'react'
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Typography } from '@mui/material';
import CardContent from '@mui/material/CardContent';

import Card from '@mui/material/Card';
import ArrowCircleLeftOutlinedIcon from '@mui/icons-material/ArrowCircleLeftOutlined';
function Section5() {
    const settings = {
        dots: false,
        infinite: true,
        slidesToShow: 7,
        slidesToScroll: 1,
        autoplay: false,
        speed: 2000,
        autoplaySpeed: 2000,
        cssEase: "linear"
    };
  return (
    <Box sx={{ flexGrow: 1 ,}}>
    <Grid container >
      <Grid item xs={12}>
    <div className="slider-container" >
        <Box sx={{ mt: 2, backgroundColor: ' #d0d3d4 ',mb:10,height:'450px'}}>

       
         <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Typography variant='h4' sx={{ m: 2,fontWeight:'normal' }}>Best Deals on Smartphones</Typography>
                            <ArrowCircleLeftOutlinedIcon sx={{ m: 2 }} />
                        </Box>
      <Slider {...settings} gap={2}>
                         <Box sx={{width:'50px',height:'300px',border:'1px solid grey',display:'flex',alignItems:'center',mt:2}}>
                                   
                                   <img src='https://rukminim2.flixcart.com/image/210/210/xif0q/shoe/q/l/d/-original-imagg42rzpcfb6cy.jpeg?q=80' style={{width:'70%',height:'200px',padding:'10px 10px 10px 10px'}} alt='...' />
                                   <Typography variant='h6' sx={{color:'grey',textAlign:'center'}}>Realme P1 5g</Typography>
                                   <Typography variant='h6' sx={{fontWeight:'bold',textAlign:'center'}}>From $14,999</Typography>
                          </Box>
                          <Box sx={{width:'100px',height:'300px',border:'1px solid grey',display:'flex',alignItems:'center',mt:2}}>
                                   
                                   <img src='https://rukminim2.flixcart.com/image/210/210/xif0q/mobile/y/9/0/-original-imahyuhfg2z4fvyh.jpeg?q=80' style={{width:'90%',height:'200px',padding:'10px 15px 10px 15px'}} alt='...' />
                                   <Typography variant='h6' sx={{color:'grey',textAlign:'center'}}>Realme P1 5g</Typography>
                                   <Typography variant='h6' sx={{fontWeight:'bold',textAlign:'center'}}>From $14,999</Typography>
                          </Box>
                          <Box sx={{width:'100px',height:'300px',border:'1px solid grey',display:'flex',alignItems:'center',mt:2}}>
                                   
                                   <img src='https://rukminim2.flixcart.com/image/210/210/xif0q/mobile/y/9/0/-original-imahyuhfg2z4fvyh.jpeg?q=80' style={{width:'90%',height:'200px',padding:'10px 15px 10px 15px'}} alt='...' />
                                   <Typography variant='h6' sx={{color:'grey',textAlign:'center'}}>Realme P1 5g</Typography>
                                   <Typography variant='h6' sx={{fontWeight:'bold',textAlign:'center'}}>From $14,999</Typography>
                          </Box> 
                          <Box sx={{width:'100px',height:'300px',border:'1px solid grey',display:'flex',alignItems:'center',mt:2}}>
                                   
                                   <img src='https://rukminim2.flixcart.com/image/210/210/xif0q/mobile/y/9/0/-original-imahyuhfg2z4fvyh.jpeg?q=80' style={{width:'90%',height:'200px',padding:'10px 15px 10px 15px'}} alt='...' />
                                   <Typography variant='h6' sx={{color:'grey',textAlign:'center'}}>Realme P1 5g</Typography>
                                   <Typography variant='h6' sx={{fontWeight:'bold',textAlign:'center'}}>From $14,999</Typography>
                          </Box>
                           <Box sx={{width:'100px',height:'300px',border:'1px solid grey',display:'flex',alignItems:'center',mt:2}}>
                                   
                                   <img src='https://rukminim2.flixcart.com/image/210/210/xif0q/mobile/y/9/0/-original-imahyuhfg2z4fvyh.jpeg?q=80' style={{width:'90%',height:'200px',padding:'10px 15px 10px 15px'}} alt='...' />
                                   <Typography variant='h6' sx={{color:'grey',textAlign:'center'}}>Realme P1 5g</Typography>
                                   <Typography variant='h6' sx={{fontWeight:'bold',textAlign:'center'}}>From $14,999</Typography>
                          </Box>
                          <Box sx={{width:'100px',height:'300px',border:'1px solid grey',display:'flex',alignItems:'center',mt:2}}>
                                   
                                   <img src='https://rukminim2.flixcart.com/image/210/210/xif0q/mobile/y/9/0/-original-imahyuhfg2z4fvyh.jpeg?q=80' style={{width:'90%',height:'200px',padding:'10px 15px 10px 15px'}} alt='...' />
                                   <Typography variant='h6' sx={{color:'grey',textAlign:'center'}}>Realme P1 5g</Typography>
                                   <Typography variant='h6' sx={{fontWeight:'bold',textAlign:'center'}}>From $14,999</Typography>
                          </Box>
                     
       
      </Slider>
      </Box>
    </div>
     
      </Grid>
 
    </Grid>
  </Box>


  )
}

export default Section5

