import React from 'react'

function Footernavbar() {
  return (
    <Box>
      
    </div>
  )
}

export default Footernavbar
