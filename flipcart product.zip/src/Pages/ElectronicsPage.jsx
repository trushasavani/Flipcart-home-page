import React from 'react';


const ElectronicsPage = () => {
 

  return (
    <div>
      <h1>Search Results for </h1>
  

    </div>
  );
};

export default ElectronicsPage;

